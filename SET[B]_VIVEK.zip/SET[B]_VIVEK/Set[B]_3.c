/*Write a program that reverses the order of the bits in an unsigned int value. The program should
input the value from the user and call function reverseBits to print the bits in reverse order. Print the
value in bits both before and after the bits are reversed to confirm that the bits are reversed properly.*/

#include<stdio.h> 
void main() 
{ 
	int num,i,j; 
	printf("Enter the number..\n"); 
	scanf("%d",&num); 
	printf("Binary num is \n"); 
	for(i=7;i>=0;i--) 
	printf("%d",num>>i&1); 
	for(i=0,j=7;i<j;i++,j--) 
	{ 
		if(num>>i&1!=num>>j&1) 
		{ 
			num=num ^1<<i; 
			num=num^1<<j; 
		} 
	} 
	printf("\nReverse is \n"); 
	for(i=7;i>=0;i--) 
	printf("%d",num>>i&1); 
	printf("\n"); 
}
