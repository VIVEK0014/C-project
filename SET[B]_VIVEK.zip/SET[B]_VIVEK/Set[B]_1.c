/******************************************************************************
John has a string, s consisting of n lowercase English alphabetic letters. 
In one operation, he can delete any pair of adjacent letters with same value. 
For example, string �aabcc� would become either �aab� or �bcc� after operation.
John wants to reduce s as much as possible. To do this, he will repeat the 
above operation as many times as it can be performed. 
Help John out by finding and printing s non-reducible form!.

Code

*******************************************************************************/

// here we use stdio.h that contains scanf() and printf() to take i/p & display o/p //
// also string.h includes some useful function for working with strings.


#include<stdio.h>
#include<string.h>
#include<math.h>

/* for remove character we create here a new function named rem */ 

char string[100];
void rem(int i)
{
    for(;string[i]!='\0';)
    {
        string[i]=string[i+2];
        string[i+1]=string[i+3];
        i+=2;
    }
}

// here our main code is start

int main()
{
    // initialize two variable i & length and there value is 0.
    int i=0,length=0; 
    // printf is used to print 
    printf("Enter A string:- "); 
    // scanf is used to take input from user and store it in string variable
    scanf("%s",string);         
    
    for(;string[length]!='\0';length++)
    for(;i<length;)
        {
            if(string[i] == string[i+1] && (i>=0) && string[i]!='\0')
                {
                    rem(i);
                    i--;
                }
            else
                {
                    i++;
                }
        }
    if(string[0]=='\0')
        {
            printf("Empty string");
        }
    else
        {
            printf("%s\n",string);
        }
return 0;
}

